import 'package:burger_app/common/util/color_utils.dart';
import 'package:burger_app/common/widget/appbar.dart';
import 'package:burger_app/screens/product_profile_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:page_transition/page_transition.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ConstantColor.white,
      appBar: MyAppbar(
        title: 'Cepat Tepat Food',
        height: 50.0,
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 5.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            SizedBox(
              height: 10.0,
            ),
            Expanded(
              child: Container(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int i) {
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          PageTransition(
                            type: PageTransitionType.rightToLeftWithFade,
                            child: ProductProfileScreen(),
                          ),
                        );
                      },
                      child: Stack(
                        children: [
                          Container(
                            height: 200,
                            margin: EdgeInsets.only(
                              top: 15.0,
                              left: 5.0,
                              right: 5.0,
                              bottom: 20.0,
                            ),
                            padding: EdgeInsets.all(15.0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(15),
                                topRight: Radius.circular(15),
                                bottomLeft: Radius.circular(15),
                                bottomRight: Radius.circular(15),
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: ConstantColor.black.withOpacity(0.15),
                                  offset: Offset(1, 1),
                                  blurRadius: 10,
                                  spreadRadius: 2.0,
                                ),
                              ],
                              color: Color.fromRGBO(255, 255, 255, 1),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(15),
                                        topRight: Radius.circular(15),
                                        bottomLeft: Radius.circular(15),
                                        bottomRight: Radius.circular(15),
                                      ),
                                      color: ConstantColor.primaryColor,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 10.0,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Fried  Chicken Cheesy Burger',
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                          color: ConstantColor.black,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          height: 1),
                                    ),
                                    Text(
                                      'Rp. 31.000',
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                          color: ConstantColor.black,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          height: 1),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 8.0,
                                ),
                                Text(
                                  'Chicken Burger Dengan Keju Yang Mantap',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                      color: ConstantColor.grey,
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                      height: 1),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            alignment: Alignment.center,
                            child: Image.asset(
                              "assets/images/burger_big.png",
                              height: 130.0,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
